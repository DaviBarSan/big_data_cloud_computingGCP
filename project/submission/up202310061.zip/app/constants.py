PROJECT_ID = "project-up202310061-bdcc"
VERTEX_AI_BUCKET_NAME = "vertex-ai-project-up202310061"