App Engine application folder - ./app
CSV file for Vertex AI dataset - ./app/static/tflite/dataset_vertex_ai.csv
Python scripts for BigQuery dataset creation - ./app/bigQuery_dataset/dataset_creation.py
Python scripts for Vertex AI dataset creation - ./app/vertex-ai-scritps/generate_ref_data_csv.py
Python code for Google Cloud Function - ./app/function-source/main.py
